const colorDiv = document.querySelector('.container');
