function scrollToAntropologia() {
    const antropologiaElement = document.querySelector(".middle2");
    if (antropologiaElement) {
        antropologiaElement.scrollIntoView({ behavior: 'smooth' });
    }
}

function scrollToEcofeminismo() {
    const ecofeminismoElement = document.querySelector(".middle3");
    if (ecofeminismoElement) {
        ecofeminismoElement.scrollIntoView({ behavior: 'smooth' });
    }
}

function togglePopup() {
    const popup = document.getElementById('popup');
    const contatoButton = document.getElementById('contato');
    const rect = contatoButton.getBoundingClientRect();

    popup.style.top = `${rect.bottom + window.scrollY}px`;
    popup.style.left = `${rect.left + window.scrollX}px`;
    popup.style.display = popup.style.display === 'none' ? 'block' : 'none';

    contatoButton.removeEventListener('click', togglePopup);
}

function fecharPopup() {
    document.getElementById('popup').style.display = 'none';
}

document.addEventListener('DOMContentLoaded', function () {
    document.getElementById('gegeo').addEventListener('click', scrollToAntropologia);
    document.getElementById('larissa').addEventListener('click', scrollToEcofeminismo);
    document.getElementById('contato').addEventListener('click', togglePopup);
});
